import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'day'
})
export class DayPipe implements PipeTransform {

  transform(value: number, arg: any): unknown {
    if(value) {
      let d = new Date(value * 1000).toLocaleString("en-US", {timeZone: arg.timezone});
      return new Date(d)
    } //return new Date(value * 1000).getTime()arg.timezone
  }

}
