import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
const api_key = 'd94bcd435b62a031771c35633f9f310a'
const base_url = 'http://api.openweathermap.org/data/2.5/weather?'

export const cities = [2643743,2988507,2759794,3067696,3054643]
@Injectable({
  providedIn: 'root'
})
export class WeatherService {
 
  currentCity = new BehaviorSubject({})
  constructor(private http: HttpClient)  { 

  }

  getGreeting(){
    let today = new Date()
    let curHr = today.getHours()
    let greet = ''
    if (curHr < 12) {
      greet = 'good morning'

    } else if (curHr < 18) {
      greet = 'good afternoon'
    } else {
      greet = 'good evening'
    }
    return greet
  }
  
  getWeatherWithLatLong(lat, lon){
    return this.http.get(base_url+`lat=${lat}&lon=${lon}&appid=${api_key}`)
  }

  getWeatherWithCities(){
    let lat = 51.5085;
    let lon = -0.1257
    return this.http.get(`https://api.openweathermap.org/data/2.5/find?lat=${lat}&lon=${lon}&appid=${api_key}`)
  }

  getMoreDetailsByLatLong(lat, lon){
    return this.http.get(`https://api.openweathermap.org/data/2.5/onecall?lat=${lat}&lon=${lon}&exclude=minutely,hourly&appid=${api_key}`)
  }

}

