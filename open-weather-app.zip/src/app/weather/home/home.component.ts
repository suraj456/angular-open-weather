import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, Subscription } from 'rxjs';
import { IWeather } from '../IWeather';
import { WeatherService, cities } from '../weather.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {
  @ViewChild('greeting') greeting : ElementRef
  constructor(private weatherService : WeatherService, private router : Router) { }
  private subsciptions : Subscription;
  public currentWeather = new Subject()
  ngOnInit(): void {
    //this.getGeolocation();
    this.getWeather()
  }


  // getGeolocation(){
  //   let success = (location)=>{
  //     this.subsciptions.add(this.weatherService.
  //     getWeatherWithLatLong(location.coords.latitude,location.coords.longitude)
  //     .subscribe(w=>{
  //       console.log(w)
  //     }))
  //   }
  //   let err = (e)=> {
  //     console.log(e)
  //     this.getWeather([1259229])
  //   }
  //   navigator.geolocation.getCurrentPosition(success, err,{timeout:10000})

  // }

  getWeather(){
    this.weatherService.getWeatherWithCities().subscribe((cities : any)=>{
        console.log(cities)
        this.currentWeather.next(cities.list)
      })
    
  }

  navigate(item : IWeather){
    this.router.navigate(['/home/details', {lat : item.coord.lat, lon : item.coord.lon, city : item.name}])
  }


  ngAfterViewInit(){
   // this.greeting.nativeElement.innerHTML = this.weatherService.getGreeting();
  }

  // ngOnDestroy(){
  //   this.subsciptions.unsubscribe();
  // }

}
