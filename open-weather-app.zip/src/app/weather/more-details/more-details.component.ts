import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WeatherService } from '../weather.service';

@Component({
  selector: 'app-more-details',
  templateUrl: './more-details.component.html',
  styleUrls: ['./more-details.component.scss']
})
export class MoreDetailsComponent implements OnInit {
  cityWeather 
  constructor(private route : ActivatedRoute, private weatherService : WeatherService) { }

  ngOnInit(): void {
   this.route.params.subscribe(param=> {
    this.weatherService.getMoreDetailsByLatLong(param.lat, param.lon).subscribe((weather : any)=>{
      weather['name'] = param.city
      weather['region'] = weather.timezone.split('/')[0]

      this.cityWeather = weather

      console.log(weather)
    })
   })
  }

  getDate(i){
    return new Date(i * 1000)
  }

}
