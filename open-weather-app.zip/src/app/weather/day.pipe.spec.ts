import { DayPipe } from './day.pipe';

describe('DayPipe', () => {
  it('create an instance', () => {
    const pipe = new DayPipe();
    expect(pipe).toBeTruthy();
  });
});
