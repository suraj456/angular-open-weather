import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { Route, RouterModule } from '@angular/router';
import { WeatherService } from './weather.service';
import { HttpClientModule } from '@angular/common/http';
import { MoreDetailsComponent } from './more-details/more-details.component';
import { DayPipe } from './day.pipe';

const route : Route[] = [
  { path : '', component : HomeComponent},
  { path : 'details', component : MoreDetailsComponent},
  { path : '**', redirectTo : 'home', pathMatch: 'full'}
]

@NgModule({
  declarations: [
    HomeComponent,
    MoreDetailsComponent,
    DayPipe
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    HttpClientModule
  ],
  providers : [WeatherService]
})
export class WeatherModule { }
